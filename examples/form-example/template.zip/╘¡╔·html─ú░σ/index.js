let receiveData = {};
document.addEventListener("DOMContentLoaded", function () {
  window.addEventListener("message", function (event) {
    if (window.self !== top) {
      receiveData = event.data;
    }
  });
  const ro = new ResizeObserver((entries) => {
    entries.forEach((entry) => {
      const height = entry.contentRect.height;
      window.parent.postMessage(
        { type: "app-engine-form-resize", height, uniqueId },
        "*"
      );
    });
  });
  ro.observe(document.querySelector("#element"));
  return () => {
    ro.unobserve(document.querySelector("#element"));
    ro.disconnect();
  };
});

const getQueryParams = (url) => {
  const regex = /uniqueId=([a-zA-Z0-9-]+)/;
  const match = url.match(regex);
  if (match && match.length > 1) {
    return match[1];
  } else {
    return null;
  }
};

const uniqueId = getQueryParams(window.location.href);
// ��ֹ�Ự
const terminateClick = (params) => {
  window.parent.postMessage(
    { type: "app-engine-form-terminate", ...params, uniqueId },
    receiveData.origin
  );
};
// �����Ự
const resumingClick = (params) => {
  window.parent.postMessage(
    { type: "app-engine-form-resuming", ...params, uniqueId },
    receiveData.origin
  );
};
// ��������
const reStartClick = (params) => {
  window.parent.postMessage(
    { type: "app-engine-form-restart", ...params, uniqueId },
    receiveData.origin
  );
};

document.querySelector('.resuming').addEventListener('click', () => {
  resumingClick();
});
document.querySelector('.reStart').addEventListener('click', () => {
  reStartClick();
});
document.querySelector('.terminate').addEventListener('click', () => {
  terminateClick();
});